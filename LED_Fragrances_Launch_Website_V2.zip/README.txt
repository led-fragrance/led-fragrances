LED Fragrances — Launch Website V2

Open index.html to preview the website.

This version includes:
- Luxury black/gold mobile-first design
- Search and tier filters
- Eddie's Hall of Fame
- Dedicated page for every fragrance
- Pricing on every product page
- One-tap text ordering
- Editable inventory.csv

To make it public, upload the contents of this folder to a static website host and connect your domain.
